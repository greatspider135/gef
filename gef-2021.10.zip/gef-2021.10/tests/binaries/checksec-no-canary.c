/**
 * -*- mode: c -*-
 * -*- coding: utf-8 -*-
 *
 * checksec-no-canary.c
 *
 * @author: @_hugsy_
 * @licence: WTFPL v.2
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>


int main(int argc, char** argv, char** envp)
{
        return EXIT_SUCCESS;
}
